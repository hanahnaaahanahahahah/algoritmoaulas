saldo = 2000

while True:
    print("\nCAIXA ELETRÔNICO")
    print("1 - Consultar saldo")
    print("2 - Depositar")
    print("3 - Sacar")
    print("4 - Sair")

    op = int(input("Escolha uma opção: "))

    if op == 1:
        print("Saldo atual: R$", saldo)

    elif op == 2:
        valor = float(input("Digite o valor do depósito: "))

        if valor > 0:
            saldo += valor
            print("Depósito realizado com sucesso.")
            print("Saldo atual: R$", saldo)
        else:
            print("Valor inválido.")

    elif op == 3:
        valor = float(input("Digite o valor do saque: "))

        if valor > 0 and valor <= saldo:
            saldo -= valor
            print("Saque realizado com sucesso.")
            print("Saldo atual: R$", saldo)
        else:
            print("Saque inválido ou saldo insuficiente.")

    elif op == 4:
        print("Caixa eletrônico encerrado.")
        break

    else:
        print("Opção inválida.")