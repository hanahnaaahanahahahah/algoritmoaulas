nota = 0

while True:
    print("\n1 - Informar nota")
    print("2 - Consultar situação")
    print("3 - Sair")

    op = int(input("Escolha: "))

    if op == 1:
        nota = float(input("Digite a nota: "))

        if 0 <= nota <= 10:
            print("Nota registrada com sucesso.")
        else:
            print("Nota inválida.")

    elif op == 2:
        print("Nota:", nota)

        if nota >= 7:
            print("Situação: Aprovado")
        elif nota >= 3:
            print("Situação: Recuperação")
        else:
            print("Situação: Reprovado")

    elif op == 3:
        break

    else:
        print("Opção inválida.")