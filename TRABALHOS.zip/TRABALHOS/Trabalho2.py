cebolinha = 0
gohan = 0
athena = 0

while True:
    print("========== VOTAÇÃO ==========")
    print("1 - Cebolinha")
    print("2 - Gohan")
    print("3 - Athena")
    print("4 - Encerrar votação")

    voto = int(input("Digite seu voto: "))

    if voto == 1:
        cebolinha += 1
        print("Voto registrado para o Cebolinha.")

    elif voto == 2:
        gohan += 1
        print("Voto registrado para o Gohan.")

    elif voto == 3:
        athena += 1
        print("Voto registrado para a Athena.")

    elif voto == 4:
        break

    else:
        print("Opção inválida! Voto não contabilizado.")

print()
print("========== RESULTADO ==========")
print("Candidato Cebolinha:", cebolinha, "votos")
print("Candidato Gohan:", gohan, "votos")
print("Candidata Athena:", athena, "votos")